Mouse Injector v0.3.2 - Perfect Dark beta / Plus 2.4 update

Copy Mouse_Injector.dll to your emulator plugin folder. Install the matching
1964GEPD update for beta EC startup/PAL support. Keep existing settings and
cold-boot the ROM. See RELEASE-NOTES.md for controls and installation.
